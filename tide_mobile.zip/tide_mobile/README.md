# Tide Mobile 🌊
**ZERO2DEV 2026 · Session 04 — Flutter & Dart**

A minimal, polished task-manager app built with Flutter, following the Session 04 guide structure exactly.

---

## App structure (matches your guide)

| Section | File | What it does |
|---------|------|--------------|
| 1 | `lib/main.dart` | Import + Entry Point (`runApp`) |
| 2 | `lib/theme/tide_colors.dart` | Design Tokens — colours |
| 2 | `lib/theme/tide_space.dart` | Design Tokens — spacing |
| 3 | `lib/models/task.dart` | Task Data Model |
| 4 | `lib/main.dart` (`TideApp`) | Root App Widget + theme |
| 5 | `lib/screens/home_screen.dart` | Home Screen (stateful) |
| 6a | `lib/widgets/task_card.dart` | TaskCard widget |
| 6b | `lib/widgets/add_task_sheet.dart` | AddTaskSheet widget |

---

## Quick start

### Prerequisites
- Flutter SDK ≥ 3.0.0 installed ([flutter.dev](https://flutter.dev/docs/get-started/install))
- Android Studio or VS Code with Flutter extension
- An emulator or physical device

### Run the app

```bash
# 1. Navigate into the project folder
cd tide_mobile

# 2. Pull dependencies
flutter pub get

# 3. Launch
flutter run
```

### Verify the 4 core behaviours

| # | What to do | What should happen |
|---|------------|--------------------|
| 1 | Open the app | "Today" heading, a counter, 4 sample tasks (one already ticked) |
| 2 | Tap any task | Checkbox fills green, title gets strikethrough, counter decreases |
| 3 | Tap the blue + FAB | A sheet slides up from the bottom |
| 4 | Type a title, pick priority, tap Save Task | Task appears in list with the correct coloured dot |

---

## Common errors & fixes (from guide p.34)

| Error | Cause | Fix |
|-------|-------|-----|
| Red screen "Expected to find '}'" | Missing closing bracket | Click the last `}` in flutlab.io; count outward |
| Tap task, nothing happens, no error | Data changed outside `setState` | Wrap mutation inside `setState(() { ... })` |
| RenderFlex overflowed by N pixels | Content too tall for container | Wrap list in `Expanded` |
| Bottom sheet hides behind keyboard | Missing inset offset | Already handled: `viewInsets.bottom` in AddTaskSheet |
| App shows blank white screen | `main()` not calling `runApp` | Check `runApp(const TideApp())` is present |

---

## State architecture (guide p.29–30)

```
HomeScreen (_HomeScreenState)
│  owns:  List<Task> tasks   ← every task in the entire app
│  controls: _toggleTask, _addTask, _openAddSheet
│
├── TaskCard (StatelessWidget)
│     receives Task as input; reads isDone but never owns it
│
└── AddTaskSheet (StatefulWidget)
      owns: _controller (text input) + _priority (chip selection)
      fires: onSave callback → data flows UP to HomeScreen
```

> **PRO MOVE:** State flows **DOWN**, events flow **UP**. This one-directional pattern
> scales to any size of application without becoming confusing.

---

Built with ❤️ for ZERO2DEV 2026
