/// Section 3 — Task Data Model
/// The blueprint for a task. Every to-do item in the app is one Task object.

enum TaskPriority { high, medium, low }

class Task {
  final String id;
  String title;
  bool isDone;
  TaskPriority priority;

  Task({
    required this.id,
    required this.title,
    this.isDone = false,
    this.priority = TaskPriority.medium,
  });

  /// Convenience: human-readable label for each priority
  String get priorityLabel {
    switch (priority) {
      case TaskPriority.high:
        return 'High';
      case TaskPriority.medium:
        return 'Medium';
      case TaskPriority.low:
        return 'Low';
    }
  }
}
