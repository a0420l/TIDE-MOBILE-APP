/// Section 2 — Design Tokens
/// Consistent spacing scale. Use TideSpace.X everywhere instead of
/// raw pixel numbers so the whole app rescales uniformly.
class TideSpace {
  TideSpace._(); // private constructor — cannot instantiate

  static const double xxs  =  2.0;
  static const double xs   =  4.0;
  static const double sm   =  8.0;
  static const double md   = 16.0;
  static const double lg   = 24.0;
  static const double xl   = 32.0;
  static const double xxl  = 48.0;
  static const double xxxl = 64.0;

  // Card internals
  static const double cardPadding  = 16.0;
  static const double cardRadius   = 16.0;
  static const double cardGap      =  8.0;

  // Sheet internals
  static const double sheetRadius  = 28.0;
  static const double sheetPadding = 20.0;

  // Checkbox
  static const double checkboxSize  = 22.0;
  static const double checkboxRadius =  6.0;

  // Priority dot
  static const double dotSize = 10.0;

  // FAB
  static const double fabSize   = 56.0;
  static const double fabRadius = 18.0;
}
