import 'package:flutter/material.dart';

/// Section 2 — Design Tokens
/// All brand colours live here. Never hardcode hex values elsewhere.
class TideColors {
  TideColors._(); // private constructor — cannot instantiate

  // ── Core palette ──────────────────────────────────────────────────
  static const Color primary      = Color(0xFF3D5AF1); // ocean blue (FAB, links)
  static const Color primaryDark  = Color(0xFF2B42D6); // pressed state
  static const Color background   = Color(0xFFF5F5F0); // warm off-white
  static const Color surface      = Color(0xFFFFFFFF); // card white
  static const Color done         = Color(0xFF00C48C); // tick green

  // ── Text ──────────────────────────────────────────────────────────
  static const Color textPrimary   = Color(0xFF1A1A2E); // near-black
  static const Color textSecondary = Color(0xFF8C8FA3); // muted grey

  // ── Borders & dividers ────────────────────────────────────────────
  static const Color border      = Color(0xFFE8E8EE);
  static const Color divider     = Color(0xFFF0F0F5);

  // ── Priority dots ─────────────────────────────────────────────────
  static const Color priorityHigh   = Color(0xFFFF4757); // red
  static const Color priorityMedium = Color(0xFFFFAA00); // amber
  static const Color priorityLow    = Color(0xFFADB5BD); // slate grey

  // ── Utility ───────────────────────────────────────────────────────
  static const Color chipBlue       = Color(0xFFEEF1FF); // counter pill bg
  static const Color chipBlueBorder = Color(0xFFB8C4FF);
  static const Color shadow         = Color(0x0F000000); // subtle shadow
}
