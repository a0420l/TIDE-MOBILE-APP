/// Section 5 — Home Screen
/// The main screen: the task list, the counter, and the + button.
/// This is the stateful part — it owns List<Task> tasks for the entire app.

import 'package:flutter/material.dart';
import '../models/task.dart';
import '../theme/tide_colors.dart';
import '../theme/tide_space.dart';
import '../widgets/task_card.dart';
import '../widgets/add_task_sheet.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  // ── State: List<Task> tasks — every task in the entire app ─────────
  final List<Task> _tasks = [
    Task(
      id: 'seed-1',
      title: 'Review design system tokens',
      isDone: true,
      priority: TaskPriority.high,
    ),
    Task(
      id: 'seed-2',
      title: 'Build TaskCard widget',
      isDone: false,
      priority: TaskPriority.high,
    ),
    Task(
      id: 'seed-3',
      title: 'Set up state with setState',
      isDone: false,
      priority: TaskPriority.medium,
    ),
    Task(
      id: 'seed-4',
      title: 'Test on Android emulator',
      isDone: false,
      priority: TaskPriority.low,
    ),
  ];

  // ── Actions (events flow UP via onTap callbacks) ────────────────────

  /// Toggle isDone for the task matching [id].
  /// tasks.add / toggle MUST go inside setState — see guide p.29.
  void _toggleTask(String id) {
    setState(() {
      final task = _tasks.firstWhere((t) => t.id == id);
      task.isDone = !task.isDone;
    });
  }

  /// Append a new Task created in AddTaskSheet.
  void _addTask(String title, TaskPriority priority) {
    setState(() {
      _tasks.add(Task(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        priority: priority,
      ));
    });
  }

  /// Open the AddTaskSheet bottom sheet.
  void _openAddSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,   // lets sheet resize for keyboard
      backgroundColor: Colors.transparent,
      builder: (_) => AddTaskSheet(onSave: _addTask),
    );
  }

  // ── Derived state ───────────────────────────────────────────────────
  int get _remainingCount => _tasks.where((t) => !t.isDone).length;
  int get _totalCount => _tasks.length;

  // ── UI ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TideColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            _buildProgressBar(),
            Expanded(child: _buildTaskList()),
          ],
        ),
      ),
      floatingActionButton: _buildFAB(),
    );
  }

  // ── Header ────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        TideSpace.md,
        TideSpace.xl,
        TideSpace.md,
        TideSpace.md,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row: Title + Avatar
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _greeting(),
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: TideColors.textSecondary,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'Today',
                    style: TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      color: TideColors.textPrimary,
                      height: 1.1,
                      letterSpacing: -0.5,
                    ),
                  ),
                ],
              ),
              // Avatar placeholder
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: TideColors.primary,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Center(
                  child: Text(
                    'T',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: TideSpace.md),

          // Counter pill
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: _remainingCount == 0
                ? _buildAllDonePill()
                : _buildCounterPill(),
          ),
        ],
      ),
    );
  }

  Widget _buildCounterPill() {
    return Container(
      key: const ValueKey('counter'),
      padding: const EdgeInsets.symmetric(
        horizontal: TideSpace.md,
        vertical: TideSpace.xs + 2,
      ),
      decoration: BoxDecoration(
        color: TideColors.chipBlue,
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: TideColors.chipBlueBorder, width: 1),
      ),
      child: Text(
        '$_remainingCount of $_totalCount tasks remaining',
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: TideColors.primary,
        ),
      ),
    );
  }

  Widget _buildAllDonePill() {
    return Container(
      key: const ValueKey('alldone'),
      padding: const EdgeInsets.symmetric(
        horizontal: TideSpace.md,
        vertical: TideSpace.xs + 2,
      ),
      decoration: BoxDecoration(
        color: TideColors.done.withOpacity(0.12),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(
            color: TideColors.done.withOpacity(0.35), width: 1),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.check_circle_rounded,
              size: 14, color: TideColors.done),
          SizedBox(width: TideSpace.xs),
          Text(
            'All done — great work!',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: TideColors.done,
            ),
          ),
        ],
      ),
    );
  }

  // ── Thin progress bar ─────────────────────────────────────────────
  Widget _buildProgressBar() {
    final progress = _totalCount == 0
        ? 0.0
        : (_totalCount - _remainingCount) / _totalCount;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: TideSpace.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: progress),
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeInOut,
              builder: (_, value, __) {
                return LinearProgressIndicator(
                  value: value,
                  minHeight: 4,
                  backgroundColor: TideColors.border,
                  valueColor: const AlwaysStoppedAnimation<Color>(
                      TideColors.done),
                );
              },
            ),
          ),
          const SizedBox(height: TideSpace.md),
        ],
      ),
    );
  }

  // ── Task list ─────────────────────────────────────────────────────
  Widget _buildTaskList() {
    if (_tasks.isEmpty) return _buildEmptyState();

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(
        TideSpace.md,
        0,
        TideSpace.md,
        TideSpace.xxxl, // space above FAB
      ),
      itemCount: _tasks.length,
      separatorBuilder: (_, __) =>
          const SizedBox(height: TideSpace.cardGap),
      itemBuilder: (_, index) => TaskCard(
        task: _tasks[index],
        onTap: () => _toggleTask(_tasks[index].id),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: TideColors.chipBlue,
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(
              Icons.check_rounded,
              size: 36,
              color: TideColors.primary,
            ),
          ),
          const SizedBox(height: TideSpace.md),
          const Text(
            'Nothing here yet',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w600,
              color: TideColors.textPrimary,
            ),
          ),
          const SizedBox(height: TideSpace.xs),
          const Text(
            'Tap + to add your first task',
            style: TextStyle(
              fontSize: 14,
              color: TideColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  // ── FAB ───────────────────────────────────────────────────────────
  Widget _buildFAB() {
    return SizedBox(
      width: TideSpace.fabSize,
      height: TideSpace.fabSize,
      child: FloatingActionButton(
        onPressed: _openAddSheet,
        backgroundColor: TideColors.primary,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(TideSpace.fabRadius),
        ),
        child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────
  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning ☀️';
    if (hour < 18) return 'Good afternoon 👋';
    return 'Good evening 🌙';
  }
}
