/// Section 1 — Import and Entry Point
/// ALWAYS THE FIRST TWO LINES IN ANY FLUTTER FILE
import 'package:flutter/material.dart'; // loads Flutter's entire widget library
import 'package:flutter/services.dart';

import 'theme/tide_colors.dart'; // Section 2 — Design Tokens
import 'screens/home_screen.dart'; // Section 5 — Home Screen

/// Section 1: void main() → runApp() starts the app with TideApp as the root.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Lock to portrait only — most task apps don't need landscape
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  // Make the status bar transparent so the header looks premium
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(const TideApp());
}

/// Section 4 — Root App Widget
/// Sets the theme (font, background colour) and points to the first screen.
class TideApp extends StatelessWidget {
  const TideApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tide',
      debugShowCheckedModeBanner: false,

      // ── Theme ─────────────────────────────────────────────────────
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: TideColors.primary,
          background: TideColors.background,
          surface: TideColors.surface,
        ),
        scaffoldBackgroundColor: TideColors.background,

        // Typography — system default is fine; swap with google_fonts if desired
        textTheme: const TextTheme(
          displayLarge: TextStyle(
            fontFamily: 'SF Pro Display',
            fontWeight: FontWeight.bold,
            letterSpacing: -0.5,
          ),
        ).apply(
          bodyColor: TideColors.textPrimary,
          displayColor: TideColors.textPrimary,
        ),

        // Remove the grey splash on GestureDetector taps
        splashFactory: NoSplash.splashFactory,
        highlightColor: Colors.transparent,
      ),

      // ── First screen ───────────────────────────────────────────────
      home: const HomeScreen(),
    );
  }
}
