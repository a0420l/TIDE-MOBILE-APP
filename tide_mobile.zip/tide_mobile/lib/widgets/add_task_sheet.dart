/// Section 6b — AddTaskSheet
/// The bottom sheet that slides up when you tap +.
/// Matches your S01 Add Task screen.
/// Stateful because it owns local form state:
///   _controller (text input value) and _priority (chip selection).

import 'package:flutter/material.dart';
import '../models/task.dart';
import '../theme/tide_colors.dart';
import '../theme/tide_space.dart';

class AddTaskSheet extends StatefulWidget {
  /// Callback fires when the user taps "Save Task".
  /// HomeScreen owns _tasks; AddTaskSheet just hands data UP.
  final void Function(String title, TaskPriority priority) onSave;

  const AddTaskSheet({super.key, required this.onSave});

  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  // Local form state — these are NOT in HomeScreen
  final TextEditingController _controller = TextEditingController();
  TaskPriority _priority = TaskPriority.medium;

  @override
  void dispose() {
    _controller.dispose(); // always dispose controllers
    super.dispose();
  }

  void _handleSave() {
    final title = _controller.text.trim();
    if (title.isEmpty) {
      // Shake the text field subtly instead of a heavy dialog
      _shakeKey.currentState?.shake();
      return;
    }
    widget.onSave(title, _priority); // hand data UP to HomeScreen
    Navigator.of(context).pop();
  }

  Color _chipColor(TaskPriority p) {
    switch (p) {
      case TaskPriority.high:
        return TideColors.priorityHigh;
      case TaskPriority.medium:
        return TideColors.priorityMedium;
      case TaskPriority.low:
        return TideColors.priorityLow;
    }
  }

  final GlobalKey<_ShakeWidgetState> _shakeKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    // Bottom padding accounts for keyboard height
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: TideColors.surface,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(TideSpace.sheetRadius),
        ),
      ),
      padding: EdgeInsets.fromLTRB(
        TideSpace.sheetPadding,
        TideSpace.sm,
        TideSpace.sheetPadding,
        TideSpace.sheetPadding + bottomInset,
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Drag handle ─────────────────────────────────────
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: TideColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            const SizedBox(height: TideSpace.lg),

            // ── Heading ──────────────────────────────────────────
            const Text(
              'Add Task',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: TideColors.textPrimary,
                letterSpacing: -0.3,
              ),
            ),

            const SizedBox(height: TideSpace.md),

            // ── Text field (with optional shake) ────────────────
            _ShakeWidget(
              key: _shakeKey,
              child: TextField(
                controller: _controller,
                autofocus: true,
                textCapitalization: TextCapitalization.sentences,
                style: const TextStyle(
                  fontSize: 15,
                  color: TideColors.textPrimary,
                ),
                decoration: InputDecoration(
                  hintText: 'What do you need to do?',
                  hintStyle: const TextStyle(
                    color: TideColors.textSecondary,
                    fontSize: 15,
                  ),
                  filled: true,
                  fillColor: TideColors.background,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: TideSpace.md,
                    vertical: TideSpace.md,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        const BorderSide(color: TideColors.border, width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                        color: TideColors.primary, width: 2),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onSubmitted: (_) => _handleSave(),
              ),
            ),

            const SizedBox(height: TideSpace.lg),

            // ── Priority label ───────────────────────────────────
            const Text(
              'Priority',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
                color: TideColors.textSecondary,
              ),
            ),

            const SizedBox(height: TideSpace.sm),

            // ── Priority chips ───────────────────────────────────
            Row(
              children: TaskPriority.values.map((p) {
                final isSelected = _priority == p;
                final chipColor = _chipColor(p);
                return Padding(
                  padding: const EdgeInsets.only(right: TideSpace.sm),
                  child: GestureDetector(
                    onTap: () => setState(() => _priority = p),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.symmetric(
                        horizontal: TideSpace.md,
                        vertical: TideSpace.sm,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? chipColor
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(40),
                        border: Border.all(
                          color: isSelected ? chipColor : TideColors.border,
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            width: 7,
                            height: 7,
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? Colors.white
                                  : chipColor,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: TideSpace.xs),
                          Text(
                            p == TaskPriority.high
                                ? 'High'
                                : p == TaskPriority.medium
                                    ? 'Medium'
                                    : 'Low',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: isSelected
                                  ? Colors.white
                                  : TideColors.textPrimary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: TideSpace.xl),

            // ── Save Task button ─────────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _handleSave,
                style: ElevatedButton.styleFrom(
                  backgroundColor: TideColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text(
                  'Save Task',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Tiny shake animation widget ──────────────────────────────────────────────
// Used to give visual feedback when the user tries to save with an empty title.

class _ShakeWidget extends StatefulWidget {
  final Widget child;
  const _ShakeWidget({super.key, required this.child});

  @override
  _ShakeWidgetState createState() => _ShakeWidgetState();
}

class _ShakeWidgetState extends State<_ShakeWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 400),
  );

  late final Animation<double> _anim = Tween<double>(begin: 0, end: 1).animate(
    CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut),
  );

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void shake() {
    _ctrl.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (context, child) {
        final dx = _ctrl.isAnimating
            ? 8 * (0.5 - (_anim.value - _anim.value.floor())).abs()
            : 0.0;
        return Transform.translate(
          offset: Offset(dx, 0),
          child: child,
        );
      },
      child: widget.child,
    );
  }
}
