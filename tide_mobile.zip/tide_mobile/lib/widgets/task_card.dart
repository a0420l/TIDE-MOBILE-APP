/// Section 6a — TaskCard
/// One reusable card widget — your Session 01 card-task component, coded.
/// StatelessWidget: receives a Task as input, reads isDone but never owns it.
/// State flows DOWN (task), events flow UP (onTap callback).

import 'package:flutter/material.dart';
import '../models/task.dart';
import '../theme/tide_colors.dart';
import '../theme/tide_space.dart';

class TaskCard extends StatelessWidget {
  final Task task;
  final VoidCallback onTap;

  const TaskCard({
    super.key,
    required this.task,
    required this.onTap,
  });

  Color get _dotColor {
    switch (task.priority) {
      case TaskPriority.high:
        return TideColors.priorityHigh;
      case TaskPriority.medium:
        return TideColors.priorityMedium;
      case TaskPriority.low:
        return TideColors.priorityLow;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(
          horizontal: TideSpace.cardPadding,
          vertical: TideSpace.cardPadding,
        ),
        decoration: BoxDecoration(
          color: task.isDone
              ? TideColors.done.withOpacity(0.06)
              : TideColors.surface,
          borderRadius: BorderRadius.circular(TideSpace.cardRadius),
          border: Border.all(
            color: task.isDone
                ? TideColors.done.withOpacity(0.25)
                : TideColors.border,
            width: 1.0,
          ),
          boxShadow: task.isDone
              ? []
              : [
                  const BoxShadow(
                    color: TideColors.shadow,
                    blurRadius: 10,
                    offset: Offset(0, 2),
                  ),
                ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // ── Checkbox ────────────────────────────────────────
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeInOut,
              width: TideSpace.checkboxSize,
              height: TideSpace.checkboxSize,
              decoration: BoxDecoration(
                color: task.isDone ? TideColors.done : Colors.transparent,
                borderRadius:
                    BorderRadius.circular(TideSpace.checkboxRadius),
                border: Border.all(
                  color: task.isDone ? TideColors.done : TideColors.border,
                  width: 2.0,
                ),
              ),
              child: task.isDone
                  ? const Icon(Icons.check, size: 14, color: Colors.white)
                  : null,
            ),

            const SizedBox(width: TideSpace.md),

            // ── Title ────────────────────────────────────────────
            Expanded(
              child: Text(
                task.title,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  height: 1.4,
                  color: task.isDone
                      ? TideColors.textSecondary
                      : TideColors.textPrimary,
                  decoration: task.isDone
                      ? TextDecoration.lineThrough
                      : TextDecoration.none,
                  decorationColor: TideColors.textSecondary,
                  decorationThickness: 1.5,
                ),
              ),
            ),

            const SizedBox(width: TideSpace.sm),

            // ── Priority dot ─────────────────────────────────────
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              width: TideSpace.dotSize,
              height: TideSpace.dotSize,
              decoration: BoxDecoration(
                color: task.isDone
                    ? TideColors.textSecondary.withOpacity(0.3)
                    : _dotColor,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
